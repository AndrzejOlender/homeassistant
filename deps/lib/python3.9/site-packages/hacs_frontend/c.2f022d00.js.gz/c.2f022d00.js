import{P as a,d as p}from"./main-add588c4.js";import{P as e}from"./c.982728cb.js";a({_template:p`
    <style include="paper-item-shared-styles">
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
      }
    </style>
    <slot></slot>
`,is:"paper-item",behaviors:[e]});
